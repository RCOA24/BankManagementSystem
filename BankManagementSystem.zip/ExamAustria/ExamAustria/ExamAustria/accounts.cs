﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExamAustria //name ng project hahahahha
{
    class accounts // itong class nato need sya para ma link sa Program.cs
    {
        private int acno; //private int, need ma access ng public hahahah

        public int useracno
        {
            get { return acno; } //dito na ma-access yung acno, kasi na call na sya sa public int user acno
            set { acno = value; }
        }

        protected string name; // yung protected member accessible sya within sa class nya by derived class instances
        internal int deposit; // yung internal keyword isa syang access modifier para sa type at type members
        protected internal char type; // yung protected internal isa syang type or member na pwede ma accessed sa kahit anong code sa assembly kapag na declared sya from or within derived class
        
        private void create_account() // private sya kasi hindi pa na dedeclare sa program kapag na open na yung system, kapag na declare na sya
                                      // ma access sya sya at mag lalagay yung user ng input na gusto nya
        {
            Console.Write("\nEnter The Account No. :");
            useracno = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter The Name of the Account Holder :");
            name = Console.ReadLine();
            Console.Write("\nEnter Type of The account (C/S) :");
            type = char.Parse(Console.ReadLine());
            Console.Write("Enter The Initial amount(>-500 for Saving and >-1000 for current ) :");
            deposit = int.Parse(Console.ReadLine());
            Console.Write("\n\n\nAccount Created..");
        }
        public void createaccount() // after mag lagay ng input, mag c-create na yung account
        {
            create_account();
        }
        protected void show_Account() //kapag naglagay ka ng input na nakalink sa useracno,name,type and deposit mag s-show yung account na ginawa mo sa createaccount
        {
            Console.Write("\nAccount No. : {0} ", useracno);
            Console.Write("Account Holder Name : {0}", name);
            Console.Write("Type of Account : {0}", type);
            Console.Write("Balance Amount : {0}", deposit);
        }
        public void showAccount()
        {
            show_Account();
        }

        internal void modifyaccount() //eto ganon din,same sa naunang dalawa na create acc and show acc
        {
            Console.Write("\nAccount No. : {0}", acno);
            Console.Write("Modify Account Holder Name :");
            name = Console.ReadLine();
            Console.Write("Modify Type of Account :");
            type = char.Parse(Console.ReadLine());
            Console.Write("Modify Balance Amount : ");
            deposit = int.Parse(Console.ReadLine());
        }
        public void modify_account() //after matapos sa process sa modify acc, ma c-changed na yung content
        {
            modifyaccount();
        }
        public void accountdep() //ginamit natin yung integer x para madeclare later, so lalabas yung console.write tapos lalabas kung ilan nilagay mo
            //after non lumabas yung int x na input nilagay mo kunwari 69 pesos, mag a-add sya sa current value ng deposit.
        {
            int x;
            Console.Write("Enter the amount you want to Deposit::");
            x = int.Parse(Console.ReadLine());
            deposit += x;
        }
        public void accountdraw() //same sa accountdeposit, pero minus naman, nag withdraw kasi eh hahahahah
        {
            int x;
            Console.Write("Enter the amount you want to Withdraw::");
            x = int.Parse(Console.ReadLine());
            deposit -= x;
        }
         public void account_report() //yung account report dito yung function nya parang makikita mo yung mga info ng mga account kaya may mga choices akong nilagay
        {
            Console.Write("Acno ::{0} \nName::{1} \nType::{2} \nDeposit::{3}\n", acno, name, type, deposit);
        }

        public int retacno()
        {
            return acno;
        }
        public int retdeposit()
        {
            return deposit;
        }
        public char rettype()
        {
            return type;
        }
    }
}
