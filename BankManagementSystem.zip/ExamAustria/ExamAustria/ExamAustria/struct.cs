﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExamAustria //name ng project hahahahha
{
    struct data //yung struct isa syang value type date type na inii present nya yung data structures, meron syang parameterized constructor, static constructor at iba pa hahahaha
    {
        private void intro()
        {
            Console.Write("\n\n\n\t\t BANK MANAGEMENT SYSTEM");          
            Console.Write("\n\n\n\n\t\tMADE BY: RODNEY CHARLES O. AUSTRIA");
            Console.Write("\n\n\t\t SECOND PERIODICAL EXAMINATION");
        }
        public void showintro()
        {
            intro();
        }
        internal void load() // yung internal keyword sya yung access modifier para sa mga types at type members
                            //internal keyword ay part din ng protected internal access modifier
        {
            Console.Write("Loading"); //unang lalabas tong loading tapos lalabas yung limang tuldok, kapag naging limang tuldok na sunod na sa content na bank
            for (int i = 0; i < 5; i++) // itong loop na ito ay, sa bawat i ay mas maliit sa 5 gagawin nya lahat ng gusto nya, pero kapag na reach nya yung 5 titigil na yung loop, after ng bawat iteration ng loop mag i-increment yung i by 1(i++) 
                                        //so yung loop ay titigil na kapag na meet nya yung i < 5 yung i ay naging 5 na kaya wala nang mas maliit doon na condition
            {
                Console.Write("."); //limang tuldok lalabas with the counter of 500 miliseconds
                System.Threading.Thread.Sleep(500);
            }
        }
    }
}
