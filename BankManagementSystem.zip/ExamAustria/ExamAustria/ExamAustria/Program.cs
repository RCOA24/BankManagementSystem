﻿using System;

namespace ExamAustria //name ng project hahahahah
{
    class Program : accounts //nakalink yung accounts.cs para mag work yung system, halos andoon kasi yung flow eh
    {
        static void Main(string[] args)
        {
            enumprogram bankday = new enumprogram();
            int num, n;
            data show = new data(); //mag s-show sya ng new data mula sa struct.cs
            accounts bank = new accounts();
            show.load(); //na access na dito yung naka internal void na load dito, kasi ang sabi is show.load eh
            Console.Clear();
            show.showintro(); //ito yung parang may loading na intro sa panimula hahahhaha after mag show nyan, lalabas na yung mga content na naka console.write
            Console.Write("\n\n\n\t\tBank Active Days Are as Following");
            Console.Write("\n\n\n\n\nNumber Indicates that day is Active Whereas 0 indicates that day is off");
            bankday.showactivedays(); //dito naman ini declare natin yung enums natin sa enum.cs naka public void kaya ma-access natin sya anywhere

            do //yung do statement inii executes nya yung statement or block of statements habang yung specified boolean expression na evaluates sya into true
                //kasi yung expression nayun na evaluated after each execution ng loop, yung do-while loop mag e-executes ng isang beses or more times
                //uhmmm at any point within the do statement block, pwede sya ma istop or break out yung loop by using break; statement.
            {
                Console.Write("\n\n\n\tMain Menu");
                Console.Write("\n\t01. NEW ACCOUNT");
                Console.Write("\n\t02. DEPOSIT AMOUNT");
                Console.Write("\n\t03. Withdaw Amount");
                Console.Write("\n\t04. BALANCE ENQUIRY");
                Console.Write("\n\t05. ALL ACCOUNT HOLDERS LIST");
                Console.Write("\n\t06. MODIFY AN ACCOUNT");
                Console.Write("\n\t07. EXIT");
                Console.Write("\n\tSelect your Option (1-7)");
                n = int.Parse(Console.ReadLine());
                Console.Clear();
                switch (n) //yung switch statement pwede nya ma replaced yung if else if statement, ang advantage nya pag-gamit ng switch satement para saakin ay mas malinis tignan yung code tapos mas readable 
                {
                    case 1: //so para ma access yung create account doon sa input is dapat pindutin yung 1, kapag pinindot yung 1 is ma access yung create account and then proceed sa flow ng createaccount na nasa account.cs
                        {
                            Console.Clear();
                            show.load();
                            bank.createaccount();
                            break;
                        }
                    case 2: //same lang din ng function sa case 1
                        {
                            Console.Clear();
                            show.load();
                            bank.accountdep();
                            break;
                        }
                    case 3: //same lang din ng function sa case 2
                        {
                            Console.Clear();
                            show.load();
                            bank.accountdraw();
                            break;
                        }
                    case 4: //same lang din ng function sa case 3
                        {
                            Console.Clear();
                            show.load();
                            bank.account_report();
                            break;
                        }
                    case 5: //same lang din ng function sa case 4
                        {
                            Console.Clear();
                            show.load();
                            bank.showAccount();
                            break;
                        }
                    case 6: //medyo iba, mayroon kasing num = int.Parse eh, yung int.Parse inii convert nya yung string representation of a number to its 32-bit signed integer equivalent
                        {
                            Console.Clear();
                            show.load();
                            Console.Write("\n\n\tEnter The Account No. :");
                            num = int.Parse(Console.ReadLine());
                            bank.modifyaccount();
                            break;
                        }
                }
            } while (n != 7); //end of whileLoop
        }                     // ang tawag sa != ay inequaliy operator nag rereturn sya ng true kapag yung operands nya ay hindi equal, false otherwise.
    }
}
                